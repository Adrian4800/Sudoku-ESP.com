# Sudoku ESP — página web

Proyecto web estático del juego Sudoku ESP.

## Cómo abrirlo
1. Descomprime el ZIP.
2. Abre `index.html` en un navegador moderno.

Para publicarlo, puedes subir toda la carpeta a cualquier hosting de sitios estáticos.
No necesita servidor ni base de datos.

Incluye:
- 4 dificultades: Fácil, Medio, Difícil y Extremo.
- Generación de sudokus con solución única.
- Cronómetro, pausa, deshacer, borrar y notas.
- Pistas con bombillas.
- Cofre diario.
- Sonidos y guardado local.
- PWA mediante `manifest.json` y `sw.js`.
